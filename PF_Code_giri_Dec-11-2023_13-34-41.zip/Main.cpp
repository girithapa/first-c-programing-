/* using cast opertor  */
#include<iostream>
using namespace std;
class Operator{
                public:
				int add(int* num){
					int sum = 0;
					for (int i =0; i<10; i++)
					{
						sum = sum + num[i];

					}
					return sum;

				}


			    float average(int sum)
				{
					float total = static_cast<float>(sum)/10;
					return total;

				}	     
              };
			  int main()
			  {
				Operator op;
				int* num = new int[10];
				int sum;
				float average;
				for (int i =0;i<10;i++)
				{
				cin>>num[i];

				}
				sum =op.add(num);
				average=op.average(sum);
				cout<<sum<<endl<<average;
				delete[]num; 

			  }