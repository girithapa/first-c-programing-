/*program by using default argument*/
#include<iostream>
using namespace std;
class Display{
	
	public:
	
	void display_character (char c = '%',int num =5){

	int i;
	for(i =0;i <5;i++){

		cout<<c<<endl;
	}


	}

	
	
};
int main()
{
	
	Display d;
	d.display_character();
	d.display_character('c',5);
    return 0;
}