/* use of inline function */
#include<iostream>
using namespace std;
class Salary{
	private:
	float s,incometax,netsalary;
	public:

		inline int net_salary(float s){
				incometax =0.1*s;
				netsalary = s - incometax;
				return netsalary;
			}
};


int main()
{
	Salary obj;
	float sal,total;
	cout<<"enter the salary";
	cin>>sal;
	total =	obj.net_salary(sal);
	cout<<"net Salary of employee"<<total<<endl;
	return 0;
}